import sys

from resources.lib.timer.set_quick_epg_timer import SetQuickEpgTimer

if __name__ == "__main__":
    SetQuickEpgTimer(sys.listitem)
