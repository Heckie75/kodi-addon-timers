import xbmc


class PlayList(xbmc.PlayList):

    directUrl = None
