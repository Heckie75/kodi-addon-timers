AUDIO = "audio"
VIDEO = "video"
PICTURE = "picture"

TYPES = [AUDIO, VIDEO, PICTURE]
