import migration
import service

if __name__ == "__main__":

    migration.migrate()
    service.run()
