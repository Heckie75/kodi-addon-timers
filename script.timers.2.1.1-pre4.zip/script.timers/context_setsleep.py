import sys

from resources.lib.timer.set_sleep import SetSleep

if __name__ == '__main__':
    SetSleep(sys.listitem)
