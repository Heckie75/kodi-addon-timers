import sys
import timer

if __name__ == '__main__':
    timer.set_filename_for_timer(sys.listitem, 5)