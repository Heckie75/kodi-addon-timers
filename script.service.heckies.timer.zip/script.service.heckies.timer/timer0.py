import sys
import timer

if __name__ == '__main__':
    timer.activate_sleep(sys.listitem)    