import sys

from resources.lib.contextmenu.set_timer import SetTimer

if __name__ == "__main__":
    SetTimer(sys.listitem)
