import sys

from resources.lib.contextmenu.set_sleep import SetSleep

if __name__ == '__main__':
    SetSleep(sys.listitem)
