import sys
import xbmcaddon

if __name__ == "__main__":

    addon = xbmcaddon.Addon()
    if len(sys.argv) == 2 and sys.argv[1] == "display":
        addon.setSettingInt("a_value",  1)

    elif len(sys.argv) == 2 and sys.argv[1] == "hide":
        addon.setSettingInt("a_value",  -1)
    else:
        addon.openSettings()