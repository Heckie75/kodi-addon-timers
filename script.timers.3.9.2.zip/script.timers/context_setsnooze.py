import sys

from resources.lib.contextmenu.set_snooze import SetSnooze

if __name__ == '__main__':
    SetSnooze(label=sys.listitem.getLabel(), path=sys.listitem.getPath())
