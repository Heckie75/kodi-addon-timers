AUDIO = "audio"
VIDEO = "video"
PICTURE = "picture"
SCRIPT = "script"

TYPES = [AUDIO, VIDEO, PICTURE]
